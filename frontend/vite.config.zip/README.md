# Sport Club Planner - Frontend

Frontend React + Vite avec Tailwind CSS, React Router et React Leaflet.

Pages incluses :
- Carte publique des clubs
- Connexion / Inscription
- Création de club
- Espace admin clubs
- Planning d'un entraînement
- Inscription à un entraînement (membre)
- Inscription à un entraînement d'essai (non connecté, 3 essais max côté UI)

Ce frontend est prêt à être branché sur une API Laravel.
